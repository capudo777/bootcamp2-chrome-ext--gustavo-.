# Bootcamp Helper - Extensão Chrome (Manifest V3)

## 🚀 Visão Geral

O **Bootcamp Helper** é uma extensão de navegador desenvolvida como parte do Bootcamp II, com o objetivo de demonstrar a implementação de uma extensão no padrão **Manifest V3** do Google Chrome.

A extensão inclui a funcionalidade mínima exigida:
1.  **Popup Interativo**: Interface para interação direta com o usuário.
2.  **Service Worker (Background)**: Lógica de background para gerenciar eventos e comunicação.
3.  **Content Script (Opcional)**: Script injetado em páginas específicas para manipulação do DOM.

## ✨ Funcionalidades

*   **Comunicação Bidirecional**: O popup envia uma mensagem de `PING` para o Service Worker, que responde com o status de atividade e o horário atual.
*   **Contagem de Uso**: O Service Worker registra o número de vezes que o `PING` foi acionado e a data de instalação da extensão, armazenando os dados no `chrome.storage.local`.
*   **Manipulação do DOM**: O Content Script é injetado em páginas do `https://developer.chrome.com/*` para destacar links e títulos, além de injetar um *badge* de status.
*   **Estrutura MV3**: Uso correto de `manifest_version: 3`, `action`, `background.service_worker` e `permissions` mínimas.

## 🛠️ Estrutura do Projeto

O projeto segue a estrutura de pastas sugerida para extensões de médio porte, garantindo organização e clareza:

```
bootcamp2-chrome-ext/
├─ src/
│  ├─ popup/
│  │  ├─ popup.html  <- Interface do popup
│  │  ├─ popup.js    <- Lógica do popup (comunicação com background)
│  │  └─ popup.css   <- Estilos do popup
│  ├─ background/
│  │  └─ service-worker.js <- Lógica de background (eventos, storage, PING/PONG)
│  ├─ content/
│  │  └─ content.js  <- Script injetado no DOM (destaque de elementos)
│  └─ styles/       <- (Vazio, para expansão futura)
├─ icons/
│  ├─ icon16.png
│  ├─ icon32.png
│  ├─ icon48.png
│  └─ icon128.png   <- Ícones da extensão
├─ docs/
│  └─ index.html    <- Landing Page para GitHub Pages
├─ manifest.json   <- Arquivo de configuração principal (MV3)
├─ README.md       <- Este arquivo
├─ LICENSE         <- Licença do projeto (MIT)
└─ .gitignore      <- Arquivos a serem ignorados pelo Git
```

## ⚙️ Instalação Manual (Modo Desenvolvedor)

Para testar a extensão localmente no Google Chrome ou navegadores baseados em Chromium:

1.  **Clone o Repositório** (ou baixe o arquivo ZIP e descompacte).
2.  Abra o Chrome e navegue para `chrome://extensions`.
3.  Ative o **Modo Desenvolvedor** (chave no canto superior direito).
4.  Clique em **Carregar sem compactação** (Load unpacked).
5.  Selecione a pasta raiz do projeto (`bootcamp2-chrome-ext/`).

A extensão será instalada e o ícone aparecerá na barra de ferramentas.

## 📝 Permissões Mínimas

A extensão utiliza o **princípio do menor privilégio**, solicitando apenas as permissões estritamente necessárias para suas funcionalidades:

| Permissão | Propósito |
| :--- | :--- |
| `storage` | Armazenar a data de instalação e a contagem de PINGs localmente. |
| `tabs` | Necessário para o Service Worker interagir com as abas do navegador (ex: `chrome.tabs.onActivated`). |
| `host_permissions` | Permite a injeção do Content Script em `https://developer.chrome.com/*`. |

## 📄 Licença

Este projeto está licenciado sob a Licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.
