/**
 * popup.js - Lógica do popup da extensão
 * 
 * Responsável por:
 * - Comunicação com o service worker via chrome.runtime.sendMessage
 * - Atualização da UI com respostas do background
 * - Gerenciamento de eventos de botões
 */

// Elementos do DOM
const pingBtn = document.getElementById('ping');
const statsBtn = document.getElementById('getStats');
const statusEl = document.getElementById('status');

/**
 * Função para enviar mensagem PING ao background
 * e atualizar o status na UI
 */
pingBtn.addEventListener('click', async () => {
    try {
        // Desabilita botão durante a requisição
        pingBtn.disabled = true;
        statusEl.textContent = 'Verificando...';
        statusEl.classList.remove('success', 'error');

        // Envia mensagem ao service worker
        const response = await chrome.runtime.sendMessage({ 
            type: 'PING' 
        });

        // Atualiza UI com resposta
        if (response && response.ok) {
            statusEl.textContent = `✓ Background está vivo!\nTempo: ${response.time}`;
            statusEl.classList.add('success');
        } else {
            statusEl.textContent = '✗ Erro na resposta do background';
            statusEl.classList.add('error');
        }
    } catch (error) {
        // Tratamento de erro
        statusEl.textContent = `✗ Erro: ${error.message}`;
        statusEl.classList.add('error');
        console.error('Erro ao enviar PING:', error);
    } finally {
        // Reabilita botão
        pingBtn.disabled = false;
    }
});

/**
 * Função para obter estatísticas armazenadas no storage
 */
statsBtn.addEventListener('click', async () => {
    try {
        statsBtn.disabled = true;
        statusEl.textContent = 'Carregando estatísticas...';
        statusEl.classList.remove('success', 'error');

        // Obtém dados do storage local
        const data = await chrome.storage.local.get(['installs', 'pings']);

        // Formata e exibe as estatísticas
        let statsText = '📊 Estatísticas da Extensão:\n\n';
        
        if (data.installs) {
            const installDate = new Date(data.installs).toLocaleString('pt-BR');
            statsText += `Instalada em: ${installDate}\n`;
        } else {
            statsText += 'Instalada em: Não registrado\n';
        }

        statsText += `Total de PINGs: ${data.pings || 0}`;

        statusEl.textContent = statsText;
        statusEl.classList.add('success');
    } catch (error) {
        statusEl.textContent = `✗ Erro ao carregar estatísticas: ${error.message}`;
        statusEl.classList.add('error');
        console.error('Erro ao obter estatísticas:', error);
    } finally {
        statsBtn.disabled = false;
    }
});

/**
 * Carrega status inicial ao abrir o popup
 */
document.addEventListener('DOMContentLoaded', () => {
    statusEl.textContent = 'Extensão carregada e pronta!';
    statusEl.classList.add('success');
});
