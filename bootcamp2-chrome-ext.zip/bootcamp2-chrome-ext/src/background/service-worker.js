/**
 * service-worker.js - Service Worker da extensão (Manifest V3)
 * 
 * Responsável por:
 * - Inicialização da extensão (onInstalled)
 * - Comunicação com popup via chrome.runtime.onMessage
 * - Gerenciamento de storage local
 * - Eventos de background
 */

/**
 * Evento disparado quando a extensão é instalada ou atualizada
 */
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        // Primeira instalação
        console.log('Bootcamp Helper instalado com sucesso!');
        
        // Inicializa dados no storage
        chrome.storage.local.set({
            installs: Date.now(),
            pings: 0,
            version: '1.0.0'
        });

        // Abre a página de boas-vindas (opcional)
        // chrome.tabs.create({ url: 'chrome://extensions' });
    } else if (details.reason === 'update') {
        // Atualização da extensão
        console.log('Bootcamp Helper atualizado!');
    }
});

/**
 * Listener para mensagens do popup
 * Responde a diferentes tipos de mensagens
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Mensagem recebida:', message);

    // Responde a PING
    if (message.type === 'PING') {
        sendResponse({
            ok: true,
            time: new Date().toISOString(),
            message: 'Pong!'
        });

        // Incrementa contador de PINGs
        chrome.storage.local.get(['pings'], (result) => {
            const currentPings = result.pings || 0;
            chrome.storage.local.set({ pings: currentPings + 1 });
        });
    }

    // Responde a requisições de status
    else if (message.type === 'GET_STATUS') {
        chrome.storage.local.get(null, (data) => {
            sendResponse({
                ok: true,
                data: data
            });
        });
        // Retorna true para indicar que a resposta será enviada de forma assíncrona
        return true;
    }

    // Responde a requisições desconhecidas
    else {
        sendResponse({
            ok: false,
            message: 'Tipo de mensagem desconhecido'
        });
    }
});

/**
 * Listener para mudanças no storage
 * Útil para sincronizar estado entre abas
 */
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
        console.log('Storage local foi alterado:', changes);
    }
});

/**
 * Listener para eventos de ativação de tabs
 * Exemplo de interação com tabs
 */
chrome.tabs.onActivated.addListener((activeInfo) => {
    console.log(`Aba ativada: ${activeInfo.tabId}`);
});

// Log de inicialização do service worker
console.log('Service Worker do Bootcamp Helper carregado e pronto!');
