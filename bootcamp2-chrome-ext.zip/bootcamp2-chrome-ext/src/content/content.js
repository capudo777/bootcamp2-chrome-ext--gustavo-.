/**
 * content.js - Content Script da extensão
 * 
 * Responsável por:
 * - Manipulação do DOM em páginas específicas (matches no manifest)
 * - Injeção de estilos e elementos na página
 * - Comunicação com o popup e background
 * 
 * Este script é injetado apenas em: https://developer.chrome.com/*
 */

/**
 * Função para destacar elementos na página
 */
function highlightElements() {
    // Destaca todos os links
    const links = document.querySelectorAll('a');
    links.forEach((link, index) => {
        link.style.outline = '2px solid #667eea';
        link.style.outlineOffset = '2px';
        link.title = `Link ${index + 1}`;
    });

    // Destaca títulos
    const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    headings.forEach((heading) => {
        heading.style.backgroundColor = 'rgba(102, 126, 234, 0.1)';
        heading.style.padding = '5px';
        heading.style.borderRadius = '4px';
    });

    console.log(`Content script: ${links.length} links destacados`);
}

/**
 * Função para injetar um badge na página
 */
function injectBadge() {
    // Cria elemento do badge
    const badge = document.createElement('div');
    badge.id = 'bootcamp-helper-badge';
    badge.textContent = '🚀 Bootcamp Helper Ativo';
    
    // Estilos do badge
    badge.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 12px 16px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        cursor: pointer;
        transition: all 0.3s ease;
    `;

    // Adiciona interatividade ao badge
    badge.addEventListener('mouseenter', () => {
        badge.style.transform = 'scale(1.05)';
    });

    badge.addEventListener('mouseleave', () => {
        badge.style.transform = 'scale(1)';
    });

    badge.addEventListener('click', () => {
        alert('Bootcamp Helper está ativo nesta página!\n\nLinks e títulos foram destacados.');
    });

    // Injeta badge no DOM
    document.body.appendChild(badge);
}

/**
 * Função para log de informações da página
 */
function logPageInfo() {
    const info = {
        title: document.title,
        url: window.location.href,
        links: document.querySelectorAll('a').length,
        headings: document.querySelectorAll('h1, h2, h3, h4, h5, h6').length,
        timestamp: new Date().toISOString()
    };

    console.log('Bootcamp Helper - Informações da Página:', info);
}

/**
 * Executa as funções quando o DOM está pronto
 */
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        highlightElements();
        injectBadge();
        logPageInfo();
    });
} else {
    // DOM já está pronto (document_idle)
    highlightElements();
    injectBadge();
    logPageInfo();
}

/**
 * Listener para mudanças dinâmicas no DOM
 * Útil para sites com carregamento dinâmico
 */
const observer = new MutationObserver((mutations) => {
    // Opcionalmente, re-aplica destaques em novos elementos
    // highlightElements();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

console.log('Content script do Bootcamp Helper carregado!');
